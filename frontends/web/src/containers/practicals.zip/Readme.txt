Instructions for the students
*****************************
1. Navigate to the "Examples" tab/subpage on your "Profile" page.
2. The subpage has a table that lists all tasks, and displays the user's stats on those tasks.
3. For each of the tasks, click on the "Export" button that allows you to export your student data for that task.
4. Email your teacher the exported json file.


Instructions for the teacher
****************************
1. Create a local directory 'scores' to store all the json files that you received from all your students.
2. The title of the json file should match the 1st line of the json file for any new students added. 
   Example: studentA.json line 1 should start with: {"studentA":[
3. Use the jupyter notebook that has a sample query and sample json files to score the students performance.
4. The anon_uid field for an example designates the user that created the example. So if you want to find the 
   MER for a student with the anon_uid of 5c32c026d6a7bd0e84a6e43d08d1e4640735540c, then you could filter all 
   examples so that they have that anon_uid, and then compute #model wrong/total. The example notebook contains 
   the code needed to compute and display the top student's MER.

